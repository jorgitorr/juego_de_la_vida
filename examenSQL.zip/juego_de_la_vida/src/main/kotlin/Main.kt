
fun main() {
    menu()
}

fun menu(){
    var conexion = Conexion("root","")
    conexion.conectarBD()
    conexion.crearTablaProductos()
    conexion.crearTablaMovimientos()
    conexion.crearTablaCompras()
    conexion.crearTablaVentas()
    conexion.crearTablaSaldo()


    //inserta productos
    conexion.insertarProductos(1,"Papas fritas",0)
    conexion.insertarProductos(2,"Huevos",0)
    conexion.insertarProductos(3,"Gazpacho",9)

    println("el numero de productos es: " + conexion.numProductos())
    println("el saldo en la caja es: " + conexion.saldoCaja())



}




