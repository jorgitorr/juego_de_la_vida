import java.sql.*



class Conexion(val usuario:String, val contrasenia:String){

    var conexion: Connection? = null

    init {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver")
        } catch (e: ClassNotFoundException) {
            throw SQLException("La base de datos no esta encendida")
        }
    }


    fun conectarBD(): Connection {
        val direccionBD = "jdbc:mysql://localhost:3306/ventas"
        val usuario = usuario
        val contrasenia = contrasenia
        try {
            if (conexion == null || conexion!!.isClosed) {
                conexion = DriverManager.getConnection(direccionBD, usuario, contrasenia)
                println("Bienvenido")
            }
            return conexion!!
        } catch (e: SQLException) {
            throw e
        }
    }


    fun cerrarBD() {
        try {
            conexion?.close()
        } catch (e: SQLException) {
            throw e
        }
    }

    fun crearTablaProductos(){
        try {
            val tabla1 = "CREATE TABLE Productos (\n" +
                    "    id INT PRIMARY KEY,\n" +
                    "    nombre VARCHAR(255) NOT NULL,\n" +
                    "    stock INT NOT NULL\n" +
                    ");"
            val creaTabla1: PreparedStatement = conexion!!.prepareStatement(tabla1)
            creaTabla1.executeUpdate()
        }catch (e: Exception){
            System.err.println("Error de creacion de Productos")
        }

    }

    fun crearTablaMovimientos(){
        try {
            val tabla2 = "CREATE TABLE Movimientos (\n" +
                    "    id INT PRIMARY KEY AUTO_INCREMENT,\n" +
                    "    tipo VARCHAR(10) NOT NULL,\n" +
                    "    monto DOUBLE NOT NULL,\n" +
                    "    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n" +
                    ");"
            val creaTabla2: PreparedStatement = conexion!!.prepareStatement(tabla2)
            creaTabla2.executeUpdate()
        }catch (e: Exception){
            System.err.println("Error de creacion de Movimientos")
        }
    }

    fun crearTablaCompras(){
        try {
            val tabla2 = "CREATE TABLE Compras (\n" +
                    "    id INT PRIMARY KEY AUTO_INCREMENT,\n" +
                    "    id_producto INT NOT NULL,\n" +
                    "    cantidad INT NOT NULL,\n" +
                    "    precio_unitario DOUBLE NOT NULL,\n" +
                    "    total DOUBLE NOT NULL,\n" +
                    "    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n" +
                    "    FOREIGN KEY (id_producto) REFERENCES Productos(id)\n" +
                    ");"
            val creaTabla2: PreparedStatement = conexion!!.prepareStatement(tabla2)
            creaTabla2.executeUpdate()
        }catch (e: Exception){
            System.err.println("Error de creacion de Compras")
        }
    }

    fun crearTablaVentas(){
        try {
            val tabla2 = "CREATE TABLE Ventas (\n" +
                    "    id INT PRIMARY KEY AUTO_INCREMENT,\n" +
                    "    id_producto INT NOT NULL,\n" +
                    "    cantidad INT NOT NULL,\n" +
                    "    precio_unitario DOUBLE NOT NULL,\n" +
                    "    total DOUBLE NOT NULL,\n" +
                    "    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n" +
                    "    FOREIGN KEY (id_producto) REFERENCES Productos(id)\n" +
                    ");\n"
            val creaTabla2: PreparedStatement = conexion!!.prepareStatement(tabla2)
            creaTabla2.executeUpdate()
        }catch (e: Exception){
            System.err.println("Error de creacion de Ventas")
        }
    }

    fun crearTablaSaldo(){
        try {
            val tabla2 = "CREATE TABLE Saldo (\n" +
                    "    id INT PRIMARY KEY AUTO_INCREMENT,\n" +
                    "    importe DOUBLE NOT NULL,\n" +
                    "    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n" +
                    ");"
            val creaTabla2: PreparedStatement = conexion!!.prepareStatement(tabla2)
            creaTabla2.executeUpdate()
        }catch (e: Exception){
            System.err.println("Error de creacion de Saldo")
        }
    }

    fun insertarProductos(id:Int, nombre:String, stock:Int){
        try {
            val insertar = "INSERT INTO Productos(id, nombre, stock) VALUES(?, ? ,?)"
            val insercion: PreparedStatement = conexion!!.prepareStatement(insertar)
            insercion.setInt(1,id)
            insercion.setString(2, nombre)
            insercion.setInt(3, stock)
            insercion.executeUpdate()
        }catch (e:Exception){
            System.err.println("Error de ingreso en tablas")
        }
    }


    /**
     * Celulas vivas por generacion
     */
    fun numProductos():Int{
        val productos = ArrayList<Producto>()
        try {
            val insert: PreparedStatement = conexion!!.prepareStatement("SELECT id, nombre, stock AS id, nombre, stock FROM productos WHERE stock = 0 for update;")
            val valor = insert.executeQuery()


            if (valor.next()) {
                //saco el id, nombre y stock dfe los productos para ir creando cada producto
                val idProductos = valor.getInt("id")
                val nombreProducto = valor.getString("nombre")
                val stockProducto = valor.getInt("stock")
                //agrego cada producto al arraylist de productos
                productos.add(Producto(idProductos,nombreProducto,stockProducto))
            } else {
                println("No se encontraron resultados")
            }

        } catch (e: Exception) {
            e.printStackTrace()
            println("Error: ${e.message}")
        }
        //devuelve la cantidad de productos que he ingresado
        return productos.size
    }



    fun saldoCaja(): Int {
        var saldoFinal = 0
        try{
            val consulta = "SELECT SUM(importe) AS saldoFinal FROM saldo;"
            val insert: PreparedStatement = conexion!!.prepareStatement(consulta)
            val valor = insert.executeQuery()

            if(valor.next()){
                saldoFinal = valor.getInt("saldoFinal")
            }
        }catch (e:Exception){
            System.err.println("Error al realizar la consulta")
        }

        return saldoFinal;
    }

    fun compraProductos(){
        val consulta = "INSERT INTO Compra VALUES ;"
    }




}